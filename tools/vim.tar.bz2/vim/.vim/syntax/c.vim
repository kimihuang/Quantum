"highlight Functions
autocmd FileType c call HighlightCfunction()
autocmd FileType c++ call HighlightCfunction()
autocmd FileType java call HighlightCfunction()
function! HighlightCfunction()
    syn match cFunctions display "\<[a-zA-Z_][a-zA-Z_0-9]*\>[^()]*)("me=e-2                                                                                                                  
    syn match cFunctions display "\<[a-zA-Z_][a-zA-Z_0-9]*\>\s*("me=e-1
    "hi cFunctions ctermfg=3 guifg=goldenrod
    "hi def link cFunction              Function
    hi cFunctions gui=NONE cterm=bold ctermfg=blue
endfunc
syn match cFunctions display "\<[a-zA-Z_][a-zA-Z_0-9]*\>[^()]*)("me=e-2                                                                                                                  
syn match cFunctions display "\<[a-zA-Z_][a-zA-Z_0-9]*\>\s*("me=e-1
"hi cFunctions ctermfg=3 guifg=goldenrod
hi def link cFunctions              Function 
hi cFunctions gui=NONE cterm=bold ctermfg=blue
