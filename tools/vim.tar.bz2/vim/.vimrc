if filereadable(expand("~/.vimrc.bundles"))
    source ~/.vimrc.bundles
endif

set nu     "show line number
set nowrap "no huanhang
set shiftwidth=4 "default indent 4
set softtabstop=4 "use tab 4 blank space
set smarttab
set ts=4 " tap represent 4 blank space
set noexpandtab
"%retab!
set laststatus=2 "always show line status
"colorscheme solo_dark "color mode
"colorscheme hl "color mode
colorscheme tokyo_metro "color mode
"colorscheme hlevening "color mode
"colorscheme tokyo_metro "color mode
"colorscheme torte "color mode
"colorscheme morning "color mode
"colorscheme desert
syn on
filetype on
set nocompatible
set history=1000
set background=dark
syntax on
set cindent
"set smartindent
set showmatch
set ruler
if has('mouse')
set mouse=a
endif
set incsearch
set cursorline
set hlsearch
"set autochdir
set laststatus=2
set statusline=[%F]%y%r%m%*%=[Line:%l/%L,Column:%c][%p%%] "显示文件名：总行数，总的字符数
set ruler "在编辑过程中，在右下角显示光标位置的状态行
set mouse=a
set tags=tags;
set cscopetag      " same as set cst
"set cscoperelative " same as set csre
set cscopeprg=gtags-cscope
"set cscopequickfix=c-,d-,e-,f-,g0,i-,s-,t-
command! -nargs=+ -complete=dir FindFiles :call FindFiles(<f-args>)
if has("cscopexx")
    set csprg=/usr/local/bin/cscope                         "你的cscope程序路径
    set csto=0
    set cst
    set nocsverb                                            "不在shell提示添加成功echo
    if filereadable("cscope.out")
        cs add cscope.out
    else
        let cscope_file=findfile("cscope.out",".;")
        let cscope_pre=matchstr(cscope_file,".*/")
        if !empty(cscope_file)&&filereadable(cscope_file)
            exe "cs add" cscope_file  cscope_pre
        endif
    endif
endif
nmap <C-i>s :cs find s <C-R>=expand("<cword>")<CR><CR>
nmap <C-i>g :cs find g <C-R>=expand("<cword>")<CR><CR>
nmap <C-i>d :cs find d <C-R>=expand("<cword>")<CR><CR>
nmap <C-i>c :cs find c <C-R>=expand("<cword>")<CR><CR>
nmap <C-i>t :cs find t <C-R>=expand("<cword>")<CR><CR>
nmap <C-i>e :cs find e <C-R>=expand("<cword>")<CR><CR>
nmap <C-i>f :cs find f <C-R>=expand("<cfile>")<CR><CR>
nmap <C-i>i :cs find i ^<C-R>=expand("<cfile>")<CR>$<CR>
nmap <C-i>a :Ag <C-R>=expand("<cword>")<CR><CR>

"configure for CtrlP smartTab
let g:ctrlp_extensions = ['smarttabs']
let g:ctrlp_smarttabs_modify_tabline = 0

"configure for CtrlP
let g:ctrlp_map = '<c-p>'
let g:ctrlp_cmd = 'CtrlP'
let g:ctrlp_working_path_mode = 'r'
let g:ctrlp_switch_buffer = 'et'
map <leader>f :CtrlPMRU<CR>
set wildignore+=*/tmp/*,*.so,*.swp,*.zip,*.o
"let g:ctrlp_custom_ignore = '\v[\/]\.(git|hg|svn)$'
let g:ctrlp_custom_ignore = {
  \ 'dir':  '\v[\/]\.(git|hg|svn)$',
  \ 'file': '\v\.(exe|so|dll)$',
  \ 'link': 'some_bad_symbolic_links',
  \ }

set csto=0
set csverb
set cst
function! FindFiles(pat, ...)
     let path = ''
     for str in a:000
         let path .= str . ','
     endfor

     if path == ''
         let path = &path
     endif

     echo 'finding...'
     redraw
     call append(line('$'), split(globpath(path, a:pat), '\n'))
     echo 'finding...done!'
     redraw
endfunc

function! VimEnterCallback()
     for f in argv()
         if fnamemodify(f, ':e') != 'c' && fnamemodify(f, ':e') != 'h' && fnamemodify(f, ':e') != 'cpp'
             continue
         endif

         call LoadGtags(f)
     endfor
endfunc

function! FindGtags(f)
     let gtags = ""
     let dir = fnamemodify(a:f, ':p:h')
     while 1
         let tmp = dir . '/GTAGS'
         if filereadable(tmp)
             let gtags = tmp
             break
         elseif dir == '/'
             break
         endif

         let dir = fnamemodify(dir, ":h")
     endwhile
     return gtags
endfunc

function! LoadGtags(f)
     let gtags = FindGtags(a:f)
     let dir = fnamemodify(a:f, ':p:h')
     set nocsverb
     exec 'cs add ' . gtags . ' ' . dir . ' -a'
     set csverb
endfunc

function! UpdateGtags(f)
    let dir = fnamemodify(a:f, ':p:h')
    let fname = fnamemodify(a:f, ':p')
    let found = 0
    while 1
        let tmp = dir . '/GTAGS'
        if filereadable(tmp)
            let found = 1
            break
        elseif dir == '/'
            break
        endif
        let dir = fnamemodify(dir, ":h")
    endwhile
    if found == 1
        exe 'silent !cd ' . dir . ' && gtags --single-update ' . fname . '&'
    endif
endfunction
au VimEnter * call VimEnterCallback()
au BufEnter * call LoadGtags(expand('<afile>'))
au BufWritePost * call UpdateGtags(expand('<afile>'))
nmap <C-i>s :cs find s <C-R>=expand("<cword>")<CR><CR>
nmap <C-i>g :cs find g <C-R>=expand("<cword>")<CR><CR>
nmap <C-i>d :cs find d <C-R>=expand("<cword>")<CR><CR>
nmap <C-i>c :cs find c <C-R>=expand("<cword>")<CR><CR>
nmap <C-i>t :cs find t <C-R>=expand("<cword>")<CR><CR>
nmap <C-i>e :cs find e <C-R>=expand("<cword>")<CR><CR>
nmap <C-i>f :cs find f <C-R>=expand("<cfile>")<CR><CR>
nmap <C-i>i :cs find i ^<C-R>=expand("<cfile>")<CR>$<CR>
nmap <C-i>a :Ag <C-R>=expand("<cword>")<CR><CR>


"nerdtree
""映射
map <F2> :NERDTreeToggle<CR>
""修改树的显示图标
let g:NERDTreeDirArrowExpandable = '+'
let g:NERDTreeDirArrowCollapsible = '-'
""窗口位置
let g:NERDTreeWinPos='left'
""窗口尺寸
let g:NERDTreeSize=30
""窗口是否显示行号
let g:NERDTreeShowLineNumbers=1
""不显示隐藏文件
let g:NERDTreeHidden=0
""打开vim时如果没有文件自动打开NERDTree
"autocmd vimenter * if !argc()|NERDTree|endif
""当NERDTree为剩下的唯一窗口时自动关闭
autocmd bufenter * if (winnr("$") == 1 && exists("b:NERDTree") && b:NERDTree.isTabTree()) | q | endif
""打开vim时自动打开NERDTree
"autocmd vimenter * NERDTree

""tagbar
nmap <F3> :TagbarToggle<CR>

""easymotion
""Bundle 'Lokaltog/vim-easymotion'
let g:EasyMotion_smartcase = 1
"let g:EasyMotion_startofline = 0 " keep cursor colum when JK motion
map <Leader><leader>h <Plug>(easymotion-linebackward)
map <Leader><Leader>j <Plug>(easymotion-j)
map <Leader><Leader>k <Plug>(easymotion-k)
map <Leader><leader>l <Plug>(easymotion-lineforward)
" 重复上一次操作, 类似repeat插件, 很强大
map <Leader><leader>. <Plug>(easymotion-repeat)

""映射tabe 新建tabe
map <F4> :tabe<CR>
""映射vsp, 竖向分割
""map <C-v> :vsp<CR>
""映射vsp, 横向分割
""map <C-h> :sp<CR>

""vim-airline
let g:airline#extensions#tabline#enabled = 0
let g:airline#extensions#tabline#left_sep = '|'
let g:airline#extensions#tabline#left_alt_sep = '>'
let g:airline#extensions#tabline#formatter = 'default'
let g:airline#extensions#tabline#tab_nr_type = 1 " tab number
let g:airline#extensions#tabline#show_tab_nr = 1
let g:airline#extensions#tabline#buffer_nr_show = 0
let g:airline#extensions#tabline#fnametruncate = 16
let g:airline#extensions#tabline#fnamecollapse = 2
let g:airline#extensions#tabline#buffer_idx_mode = 1
"let g:airline_theme='silver'
map <C-k>, :bprev<CR>
map <C-k>. :bnext<CR>



""vim-indent-guides
""let g:indent_guides_enable_on_vim_startup = 1
""let g:indent_guides_auto_colors=0
""let g:indent_guides_start_level = 2
""let g:indent_guides_guide_size = 1
""autocmd VimEnter,Colorscheme * :hi IndentGuidesOdd guibg=red ctermfg=3
""autocmd VimEnter,Colorscheme * :hi IndentGuidesEven guibg=green ctermbg=4


""bufferline

" tab or buf 1
"nnoremap <leader>1 :call Tab_buf_switch(1)<cr>
" tab or buf 2
"nnoremap <leader>2 :call Tab_buf_switch(2)<cr>
" tab or buf 3
"nnoremap  <leader>3 :call Tab_buf_switch(3)<cr>
" tab or buf 4
"nnoremap  <leader>4 :call Tab_buf_switch(4)<cr>
" tab or buf 5
"nnoremap  <leader>5 :call Tab_buf_switch(5)<cr>
" tab or buf 6
"nnoremap  <leader>6 :call Tab_buf_switch(6)<cr>
" tab or buf 7
"nnoremap  <leader>7 :call Tab_buf_switch(7)<cr>
" tab or buf 8
"nnoremap  <leader>8 :call Tab_buf_switch(8)<cr>
" tab or buf 9
"nnoremap  <leader>9 :call Tab_buf_switch(9)<cr>
function! Tab_buf_switch(num) abort
    if exists('g:feat_enable_airline') && g:feat_enable_airline == 1
        execute 'normal '."\<Plug>AirlineSelectTab".a:num
    else
        if exists( '*tabpagenr' ) && tabpagenr('$') != 1
            " Tab support && tabs open
            execute 'normal '.a:num.'gt'
        else
            let l:temp=a:num
            let l:buf_index=a:num
            let l:buf_count=len(filter(range(1, bufnr('$')), 'buflisted(v:val)'))
            if l:temp > l:buf_count
                return
            endif
            while l:buf_index != 0
                while !buflisted(l:temp)
                    let l:temp += 1
                endw
                let l:buf_index -= 1
                if l:buf_index != 0
                    let l:temp += 1
                endif
            endw
            execute ':'.l:temp.'b'
        endif
    endif
endfunction
